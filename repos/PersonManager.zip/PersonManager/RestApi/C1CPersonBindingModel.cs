﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestApi
{
    public class C1CPersonBindingModel
    {
        public string GUID { get; set; }
        public string Name { get; set; }
        public string TabNum { get; set; }
        public byte[] Photo { get; set; }
    }
}
