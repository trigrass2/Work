﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestApi
{
    public class C1CPersonGroupBindingModel
    {
        public string GroupGUID { get; set; }
        public string PersonGUID { get; set; }
        public string StatusID { get; set; }
    }
}
