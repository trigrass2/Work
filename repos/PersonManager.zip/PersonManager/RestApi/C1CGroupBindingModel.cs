﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestApi
{
    public class C1CGroupBindingModel
    {
        public string GUID { get; set; }
        public string Name { get; set; }
        public string Parent_id { get; set; }
    }
}
